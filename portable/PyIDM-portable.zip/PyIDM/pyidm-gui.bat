@echo off
set "HERE=%~dp0"
start "" "%HERE%python\pythonw.exe" -c "import sys; sys.path.insert(0, r'%HERE%site'); from idm.gui import main; main()"
