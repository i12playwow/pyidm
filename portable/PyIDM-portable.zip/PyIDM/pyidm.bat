@echo off
set "HERE=%~dp0"
"%HERE%python\python.exe" "%HERE%cli_main.py" %*
